
import React, { useState, useEffect } from 'react';
import { IMAGES } from '../constants';

const HeartPhotoGallery: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIdx((prev) => (prev + 1) % IMAGES.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto animate-float">
      {/* Background Heart Glow */}
      <div className="absolute inset-0 bg-red-600/30 blur-[60px] rounded-full scale-110"></div>
      
      {/* Heart Mask SVG */}
      <svg width="0" height="0">
        <defs>
          <clipPath id="heartClip" clipPathUnits="objectBoundingBox">
            <path d="M0.5,0.88 C0.5,0.88,0.1,0.62,0.02,0.37 C-0.08,0.12,0.22,-0.12,0.5,0.18 C0.78,-0.12,1.08,0.12,0.98,0.37 C0.9,0.62,0.5,0.88,0.5,0.88" />
          </clipPath>
        </defs>
      </svg>

      <div 
        className="w-full h-full relative z-10 overflow-hidden"
        style={{ clipPath: 'url(#heartClip)' }}
      >
        {IMAGES.map((img, idx) => (
          <img
            key={img}
            src={img}
            alt={`Memory ${idx}`}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1500 ease-in-out ${
              idx === currentIdx ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
            }`}
          />
        ))}
        {/* Dark vignette inside the heart */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none z-20"></div>
      </div>
      
      {/* Decorative Outer Border */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none drop-shadow-2xl z-20 opacity-60" viewBox="0 0 100 100">
         <path 
           d="M50,88 C50,88,10,62,2,37 C-8,12,22,-12,50,18 C78,-12,108,12,98,37 C90,62,50,88,50,88" 
           fill="none" 
           stroke="#ef4444" 
           strokeWidth="1.5"
         />
      </svg>
    </div>
  );
};

export default HeartPhotoGallery;
