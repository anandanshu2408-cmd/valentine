
import React, { useState, useRef } from 'react';
import { QUESTIONS } from '../constants';

interface QuizProps {
  onComplete: () => void;
}

const Quiz: React.FC<QuizProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [noButtonPos, setNoButtonPos] = useState({ x: 0, y: 0 });
  const [isNoFloating, setIsNoFloating] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentQuestion = QUESTIONS[currentStep];

  const handleYes = () => {
    if (currentStep < QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
      // Reset NO button for the next question
      setIsNoFloating(false);
      setNoButtonPos({ x: 0, y: 0 });
    } else {
      onComplete();
    }
  };

  const moveNoButton = () => {
    if (!containerRef.current) return;
    
    const containerRect = containerRef.current.getBoundingClientRect();
    const btnWidth = 120;
    const btnHeight = 48;

    // Generate random position within the viewport bounds but relative to container
    // To make it truly annoying, we move it far away
    const maxX = window.innerWidth - btnWidth;
    const maxY = window.innerHeight - btnHeight;
    
    const newX = Math.random() * maxX;
    const newY = Math.random() * maxY;

    setIsNoFloating(true);
    setNoButtonPos({ x: newX, y: newY });
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-2xl min-h-[420px] flex flex-col items-center justify-center p-8 bg-zinc-950/60 border border-red-900/40 rounded-[2rem] backdrop-blur-2xl shadow-[0_0_100px_rgba(0,0,0,0.5)] overflow-visible">
      {/* Progress Bar */}
      <div className="absolute top-0 left-0 h-1.5 bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.8)] transition-all duration-700 rounded-full" 
           style={{ width: `${((currentStep + 1) / QUESTIONS.length) * 100}%` }}></div>
      
      <div className="text-red-500 font-bold mb-6 tracking-[0.3em] text-xs uppercase opacity-70">
        Dark Question {currentStep + 1} / {QUESTIONS.length}
      </div>

      <div className="h-40 flex items-center justify-center mb-10 px-4">
        <h2 className="text-xl md:text-2xl font-serif italic text-center text-red-100 leading-relaxed">
          "{currentQuestion.text}"
        </h2>
      </div>

      <div className="flex flex-wrap gap-6 justify-center items-center w-full">
        <button
          onClick={handleYes}
          className="px-12 py-3.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-full transition-all transform hover:scale-110 active:scale-95 shadow-[0_10px_30px_rgba(220,38,38,0.4)] z-10"
        >
          YES, ALWAYS
        </button>

        <button
          onClick={(e) => {
            e.preventDefault();
            moveNoButton();
          }}
          onMouseEnter={moveNoButton}
          style={isNoFloating ? { 
            position: 'fixed', 
            left: `${noButtonPos.x}px`, 
            top: `${noButtonPos.y}px`,
            zIndex: 9999,
            transition: 'all 0.15s ease-out'
          } : { position: 'relative' }}
          className={`px-12 py-3.5 border-2 border-red-800 text-red-800 font-bold rounded-full hover:bg-red-950/30 transition-all ${isNoFloating ? 'bg-zinc-900 pointer-events-auto' : ''}`}
        >
          NO
        </button>
      </div>

      {/* Decorative Elements */}
      <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-red-900/10 blur-[80px] rounded-full"></div>
      <div className="absolute -top-10 -left-10 w-48 h-48 bg-pink-900/10 blur-[80px] rounded-full"></div>
    </div>
  );
};

export default Quiz;
