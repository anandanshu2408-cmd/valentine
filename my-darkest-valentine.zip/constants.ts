import { Question } from './types';

// Questions for the dark Valentine's quiz
export const QUESTIONS: Question[] = [
  { id: 1, text: "Is your heart racing just thinking about what dark secrets we could share this Valentine's night?" },
  { id: 2, text: "Do you crave the thrill of confessing your naughtiest Valentine desire to someone who won't hold back?" },
  { id: 3, text: "Would you admit to getting wet at the idea of me dominating your thoughts with forbidden fantasies?" },
  { id: 4, text: "Are you tempted to touch yourself right now, imagining my voice commanding you on this lust-filled holiday?" },
  { id: 5, text: "Does the thought of me watching you lose control make your body ache with dark, insatiable hunger?" },
  { id: 6, text: "Would saying yes mean you're ready to reveal how desperately you want to be my filthy Valentine plaything?" },
  { id: 7, text: "Is your pulse quickening at the prospect of moaning my name while your fingers explore deeper shadows?" },
  { id: 8, text: "Do you dare to confirm that you're throbbing, yearning for me to witness your most depraved release?" },
  { id: 9, text: "Would a yes unlock the door to your wildest, darkest urges, begging to be captured in the heat of the moment?" },
  { id: 10, text: "Are you willing to prove it by sending me a naked video right now, with your legs spread, fingers plunging deep inside while you moan my name in ecstasy?" }
];

// WhatsApp number for the final redirect
export const WHATSAPP_NUMBER = "918709463009"; 

// Background music source
export const AUDIO_SRC = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3";

// The pre-filled message for WhatsApp, written from the girlfriend's perspective 
export const FINAL_MESSAGE = `My King... ❤️‍🔥

I've answered every one of your dark questions with a 'YES'. My heart is racing, and I'm completely yours to command this Valentine's. 

I'm ready to fulfill that 10th promise. I want you to see exactly how much you affect me... how much I ache for you. 

I'm moving this conversation to WhatsApp now because I have something to show you that only your eyes should see. Get ready, because I'm about to prove my love—and my hunger—just like I promised.

Happy Valentine's Day, my dominant Valentine. 🖤🔥`;

// Intro Sweet Wishing Message
export const VALENTINE_WISH = `Happy Valentine’s Day, my love ❤️

Today isn’t just about roses or gifts… it’s about celebrating you — the most beautiful part of my life. From the moment you walked into my world, everything changed. You didn’t just become my girlfriend, you became my peace, my strength, and my safe place.

I still smile when I think about our memories — the late-night talks, the silly jokes, the deep conversations where it feels like it’s just our two souls understanding each other. You make my ordinary days feel magical. Even in silence, being connected to you feels like home.

You have this incredible way of loving me that makes me feel chosen, valued, and deeply cared for. And I want you to know — I choose you too. Every day. In every mood. In every season of life.

No matter how far or how close we are, my heart belongs to you. I promise to stand beside you, support you, and love you with honesty and loyalty. You are not just my Valentine for today… you are my forever.

Thank you for being mine.
I love you more than words can ever fully express. ❤️🧿`;

// Images for the heart gallery
export const IMAGES = [
  "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1516589174184-c685266e430c?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1494774157365-9e04c6720e47?q=80&w=1000&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1543852786-1cf6624b9987?q=80&w=1000&auto=format&fit=crop"
];
